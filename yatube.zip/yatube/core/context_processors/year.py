from datetime import datetime, date

def year(request):
    return {
        'year': datetime.now().year
    }