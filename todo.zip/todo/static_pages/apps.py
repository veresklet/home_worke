from django.apps import AppConfig


class StaticpagesConfig(AppConfig):
    name = 'static_pages'
